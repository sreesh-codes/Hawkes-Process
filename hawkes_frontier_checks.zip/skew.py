import sys
from dataclasses import dataclass
import numpy as np, pandas as pd
REPO=sys.argv[1]; sys.path.insert(0,REPO); sys.path.insert(0,"/home/claude/checks")
from joblib import Parallel, delayed
from scipy import stats
from matched_spread import WidenedAS, P, sp
from market_maker.hawkes_market_maker import Quote
from market_maker.historical_replay import generate_synthetic_events, run_backtest
from market_maker.hawkes_execution import HawkesIntensity
from analysis.comparison import compute_metrics, make_sided, IMPACT, T_EPISODE, S0
LB, LS = sp["buy"]["lam_bar"], sp["sell"]["lam_bar"]
@dataclass(frozen=True)
class SkewAS:
    base: WidenedAS; k: float   # shift = k * impact * (expected excess net buy flow over next 1s)
    @property
    def params(self): return self.base.params
    def quote(self, s, q, t, rb, rs):
        x = self.base.quote(s, q, t)
        sh = self.k * IMPACT * ((rb-LB) - (rs-LS)) * 1.0
        return Quote(bid=x.bid+sh, ask=x.ask+sh, reservation=x.reservation+sh, spread=x.spread)
def run(seed):
    b=HawkesIntensity(sp["buy"]["mu"],sp["buy"]["alpha"],sp["buy"]["beta"]); s_=HawkesIntensity(sp["sell"]["mu"],sp["sell"]["alpha"],sp["sell"]["beta"])
    ev=generate_synthetic_events(b,s_,T_EPISODE,seed); out=[]
    for g in [0.1,0.2]:
        for e in [0.01,0.035]:
            for k in [0,1,3,10]:
                pol=SkewAS(WidenedAS(P(g),e),k)
                r=run_backtest(ev,pol,make_sided(sp),pol.params,label="",synthetic=True,impact=IMPACT,s0=S0,seed=1000+seed)
                m=compute_metrics(r); m.update(gamma=g,extra=e,k=k,seed=seed); out.append(m)
    return out
df=pd.DataFrame([x for r in Parallel(n_jobs=-1)(delayed(run)(s) for s in range(300)) for x in r])
for (g,e),sub in df.groupby(["gamma","extra"]):
    base=sub[sub.k==0].sort_values("seed")
    for k in [1,3,10]:
        a=sub[sub.k==k].sort_values("seed"); d=a.total_pnl.values-base.total_pnl.values
        print(f"g={g} extra={e} k={k:>2}: dPnL={d.mean():+.4f} (p={stats.ttest_1samp(d,0).pvalue:.1e})  dInvVar={(a.inv_var.values-base.inv_var.values).mean():+.3f}  dAdv={(a.adverse_selection_ratio.values-base.adverse_selection_ratio.values).mean():+.4f}")
