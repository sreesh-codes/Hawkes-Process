import sys, json
from dataclasses import dataclass
import numpy as np, pandas as pd
REPO = sys.argv[1]; sys.path.insert(0, REPO); sys.path.insert(0, "/home/claude/checks")
from joblib import Parallel, delayed
from matched_spread import WidenedAS, P, sp
from market_maker.hawkes_market_maker import HawkesASPolicy, Quote
from market_maker.historical_replay import generate_synthetic_events, run_backtest
from market_maker.hawkes_execution import HawkesIntensity
from analysis.comparison import compute_metrics, make_sided, IMPACT, T_EPISODE, S0

@dataclass(frozen=True)
class WidenedHawkes:
    base: HawkesASPolicy
    extra: float
    @property
    def params(self): return self.base.params
    def quote(self, s, q, t, lb, ls):
        x = self.base.quote(s, q, t, lb, ls)
        return Quote(bid=x.bid-self.extra/2, ask=x.ask+self.extra/2, reservation=x.reservation, spread=x.spread+self.extra)

G = [0.05, 0.1, 0.15, 0.2, 0.3, 0.4]; E = [0.0, 0.01, 0.02, 0.035, 0.05, 0.08]
def run_seed(seed):
    buy = HawkesIntensity(sp["buy"]["mu"], sp["buy"]["alpha"], sp["buy"]["beta"])
    sell = HawkesIntensity(sp["sell"]["mu"], sp["sell"]["alpha"], sp["sell"]["beta"])
    ev = generate_synthetic_events(buy, sell, T_EPISODE, seed)
    out = []
    for g in G:
        for e in E:
            for fam, pol in [("Static", WidenedAS(P(g), e)),
                             ("Hawkes", WidenedHawkes(HawkesASPolicy(P(g), sp["buy"]["lam_bar"], sp["sell"]["lam_bar"]), e))]:
                r = run_backtest(ev, pol, make_sided(sp), pol.params, label=fam, synthetic=True,
                                 impact=IMPACT, s0=S0, seed=1000+seed)
                m = compute_metrics(r); m.update(family=fam, gamma=g, extra=e, seed=seed); out.append(m)
    return out

def envelope(pts):  # upper-left frontier: max pnl for risk <= x
    pts = pts.sort_values("risk"); best=-1e9; keep=[]
    for _, r in pts.iterrows():
        if r.pnl > best: best = r.pnl; keep.append(r)
    return pd.DataFrame(keep)

if __name__ == "__main__":
    n = int(sys.argv[2])
    rows = Parallel(n_jobs=-1)(delayed(run_seed)(s) for s in range(n))
    df = pd.DataFrame([x for r in rows for x in r]); df.to_csv("envelope_raw.csv", index=False)
    g = df.groupby(["family","gamma","extra"]).agg(pnl=("total_pnl","mean"), sd=("total_pnl","std"),
         inv_var=("inv_var","mean"), adv=("adverse_selection_ratio","mean"), spread=("avg_spread","mean")).reset_index()
    g.to_csv("envelope_summary.csv", index=False)
    for risk in ["inv_var", "sd"]:
        print(f"\n=== Efficient frontier, risk = {risk} ===")
        fr = {}
        for fam in ["Static","Hawkes"]:
            sub = g[g.family==fam].assign(risk=g[risk]); fr[fam] = envelope(sub)
            print(fam); print(fr[fam][["gamma","extra","risk","pnl","adv"]].round(4).to_string(index=False))
        # compare at common risk levels
        lo = max(fr["Static"].risk.min(), fr["Hawkes"].risk.min()); hi = min(fr["Static"].risk.max(), fr["Hawkes"].risk.max())
        for x in np.linspace(lo, hi, 6):
            ps = np.interp(x, fr["Static"].risk, fr["Static"].pnl); ph = np.interp(x, fr["Hawkes"].risk, fr["Hawkes"].pnl)
            print(f"  risk={x:6.3f}  static={ps:6.3f}  hawkes={ph:6.3f}  gain={ph-ps:+.3f} ({(ph-ps)/ps*100:+.1f}%)")
