"""Control experiment: is the Hawkes maker better than a classical maker that is simply wider?"""
import sys, json
from dataclasses import dataclass
import numpy as np, pandas as pd
REPO = sys.argv[1]
sys.path.insert(0, REPO)
from joblib import Parallel, delayed
from market_maker import ASParameters
from market_maker.hawkes_market_maker import HawkesASPolicy, PoissonASPolicy, Quote, _reservation
from market_maker.historical_replay import generate_synthetic_events, run_backtest
from market_maker.hawkes_execution import HawkesIntensity
from analysis.comparison import compute_metrics, make_sided, IMPACT, T_EPISODE, S0

sp = json.load(open(f"{REPO}/results/hawkes_side_params.json"))

@dataclass(frozen=True)
class WidenedAS:
    params: ASParameters
    extra: float  # extra TOTAL spread ($), constant
    def quote(self, s, q, t, lam_buy=0.0, lam_sell=0.0):
        p = self.params
        r = _reservation(s, q, t, p)
        spr = p.gamma*p.sigma**2*(p.T-t) + (2/p.gamma)*np.log(1+p.gamma/p.kappa) + self.extra
        return Quote(bid=r-spr/2, ask=r+spr/2, reservation=r, spread=spr)

def P(g): return ASParameters(gamma=g, sigma=0.03477, kappa=23.96, A=1.445, T=T_EPISODE, q_max=50)

def run_seed(seed, extra):
    buy = HawkesIntensity(sp["buy"]["mu"], sp["buy"]["alpha"], sp["buy"]["beta"])
    sell = HawkesIntensity(sp["sell"]["mu"], sp["sell"]["alpha"], sp["sell"]["beta"])
    ev = generate_synthetic_events(buy, sell, T_EPISODE, seed)
    pols = {"Classical g=0.10": PoissonASPolicy(P(0.1)),
            "Hawkes g=0.10": HawkesASPolicy(P(0.1), sp["buy"]["lam_bar"], sp["sell"]["lam_bar"]),
            "Classical widened (matched spread)": WidenedAS(P(0.1), extra)}
    for g in [0.15, 0.2, 0.3, 0.5]:
        pols[f"Classical g={g:.2f}"] = PoissonASPolicy(P(g))
    for g in [0.05, 0.2]:
        pols[f"Hawkes g={g:.2f}"] = HawkesASPolicy(P(g), sp["buy"]["lam_bar"], sp["sell"]["lam_bar"])
    out = []
    for name, pol in pols.items():
        params = pol.params
        r = run_backtest(ev, pol, make_sided(sp), params, label=name, synthetic=True,
                         impact=IMPACT, s0=S0, seed=1000+seed)
        m = compute_metrics(r); m.update(strategy=name, seed=seed); out.append(m)
    return out

if __name__ == "__main__":
    n = int(sys.argv[2])
    extra = 0.14627 - 0.11957   # match published Hawkes avg spread
    rows = Parallel(n_jobs=-1)(delayed(run_seed)(s, extra) for s in range(n))
    df = pd.DataFrame([x for r in rows for x in r])
    df.to_csv("/home/claude/checks/matched_spread.csv", index=False)
    cols = ["total_pnl","sharpe","inv_var","max_drawdown","avg_spread","fill_rate","adverse_selection_ratio"]
    print(df.groupby("strategy")[cols].mean().sort_values("avg_spread").round(4).to_string())
    # paired test Hawkes vs widened
    from scipy import stats
    a = df[df.strategy=="Hawkes g=0.10"].sort_values("seed"); b = df[df.strategy=="Classical widened (matched spread)"].sort_values("seed")
    for c in ["total_pnl","inv_var","sharpe","max_drawdown","adverse_selection_ratio"]:
        d = a[c].to_numpy()-b[c].to_numpy()
        print(f"Hawkes - Widened  {c:26s} mean={d.mean():+.4f}  t-p={stats.ttest_1samp(d,0,nan_policy='omit').pvalue:.2e}  d={np.nanmean(d)/np.nanstd(d):+.2f}")
