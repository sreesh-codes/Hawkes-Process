import sys, json
import numpy as np, pandas as pd
REPO = sys.argv[1]; sys.path.insert(0, REPO); sys.path.insert(0, "/home/claude/checks")
from joblib import Parallel, delayed
from matched_spread import WidenedAS, P, sp
from market_maker.hawkes_market_maker import HawkesASPolicy, PoissonASPolicy
from market_maker.historical_replay import generate_synthetic_events, run_backtest
from market_maker.hawkes_execution import HawkesIntensity
from analysis.comparison import compute_metrics, make_sided, IMPACT, T_EPISODE, S0

def pols():
    d = {}
    for g in [0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5]:
        d[("Classical (vary gamma)", g)] = PoissonASPolicy(P(g))
    for e in [0.0, 0.01, 0.027, 0.05, 0.08, 0.12]:
        d[("Static widening (gamma=0.1)", e)] = WidenedAS(P(0.1), e)
    for g in [0.05, 0.1, 0.15, 0.2, 0.3, 0.4]:
        d[("Hawkes (vary gamma)", g)] = HawkesASPolicy(P(g), sp["buy"]["lam_bar"], sp["sell"]["lam_bar"])
    return d

def run_seed(seed):
    buy = HawkesIntensity(sp["buy"]["mu"], sp["buy"]["alpha"], sp["buy"]["beta"])
    sell = HawkesIntensity(sp["sell"]["mu"], sp["sell"]["alpha"], sp["sell"]["beta"])
    ev = generate_synthetic_events(buy, sell, T_EPISODE, seed)
    out = []
    for (fam, k), pol in pols().items():
        r = run_backtest(ev, pol, make_sided(sp), pol.params, label=fam, synthetic=True,
                         impact=IMPACT, s0=S0, seed=1000+seed)
        m = compute_metrics(r); m.update(family=fam, knob=k, seed=seed); out.append(m)
    return out

if __name__ == "__main__":
    n = int(sys.argv[2])
    rows = Parallel(n_jobs=-1)(delayed(run_seed)(s) for s in range(n))
    df = pd.DataFrame([x for r in rows for x in r]); df.to_csv("frontier_raw.csv", index=False)
    g = df.groupby(["family","knob"]).agg(pnl=("total_pnl","mean"), pnl_se=("total_pnl", lambda x: x.std()/np.sqrt(len(x))),
        inv_var=("inv_var","mean"), sd_pnl=("total_pnl","std"), spread=("avg_spread","mean"),
        fill=("fill_rate","mean"), adv=("adverse_selection_ratio","mean"), mdd=("max_drawdown","mean")).reset_index()
    g.to_csv("frontier_summary.csv", index=False)
    print(g.round(4).to_string())
