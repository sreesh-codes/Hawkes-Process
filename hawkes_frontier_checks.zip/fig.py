import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
g = pd.read_csv("envelope_summary.csv"); fr = pd.read_csv("frontier_summary.csv")
def env(sub):
    sub = sub.sort_values("inv_var"); best=-1e9; k=[]
    for _, r in sub.iterrows():
        if r.pnl > best: best=r.pnl; k.append(r)
    return pd.DataFrame(k)
S, H = env(g[g.family=="Static"]), env(g[g.family=="Hawkes"])
C = fr[fr.family=="Classical (vary gamma)"].sort_values("inv_var")
plt.rcParams.update({"font.size":10.5, "axes.edgecolor":"#52514e", "axes.labelcolor":"#0b0b0b",
                     "xtick.color":"#52514e", "ytick.color":"#52514e"})
fig, ax = plt.subplots(figsize=(8.2, 5.2), dpi=160); fig.patch.set_facecolor("#fcfcfb"); ax.set_facecolor("#fcfcfb")
ax.grid(color="#e6e5e1", lw=0.8); ax.set_axisbelow(True)
for sp_ in ["top","right"]: ax.spines[sp_].set_visible(False)
kw = dict(lw=2, ms=6, markeredgecolor="#fcfcfb", markeredgewidth=1.2)
ax.plot(S.inv_var, S.pnl, "-o", color="#2a78d6", label="Static AS, tuned (γ + constant widening)", **kw)
ax.plot(H.inv_var, H.pnl, "-^", color="#eb6834", label="Hawkes AS, tuned (γ + constant widening)", **kw)
ax.plot(C.inv_var, C.pnl, "--s", color="#1baf7a", label="Classical AS, γ only (repo's baseline)", **kw)
# repo headline points
pts = {"Repo's Hawkes (γ=0.1)": (1.2972, 5.8026), "Repo's Robust (c=1)": (1.0606, 4.4723), "Repo's Classical (γ=0.1)": (1.9779, 6.5892)}
offs = {"Repo's Hawkes (γ=0.1)": (0.10,-0.55), "Repo's Robust (c=1)": (0.12,-0.45), "Repo's Classical (γ=0.1)": (0.15,-0.55)}
for name,(x,y) in pts.items():
    ax.scatter([x],[y], s=90, facecolor="none", edgecolor="#0b0b0b", lw=1.6, zorder=5)
    dx,dy = offs[name]
    ax.annotate(name, (x,y), (x+dx, y+dy), fontsize=9, color="#0b0b0b",
                arrowprops=dict(arrowstyle="-", color="#52514e", lw=0.8))
ax.text(2.25, 7.05, "Static", color="#0b0b0b", fontsize=9.5, weight="bold")
ax.text(2.33, 6.45, "Hawkes", color="#0b0b0b", fontsize=9.5, weight="bold")
ax.set_xlim(0.2, 3.0); ax.set_ylim(1.8, 7.9)
ax.set_xlabel("Inventory variance (risk) →"); ax.set_ylabel("Mean terminal PnL per 600 s episode ($)")
ax.set_title("At equal inventory risk, a tuned static spread matches or beats the Hawkes maker",
             loc="left", fontsize=11.5, weight="bold", color="#0b0b0b", pad=20)
ax.text(0.0, 1.012, "300 paired Hawkes-flow paths (repo simulator, impact $0.002/order). Up-and-left is better.",
        transform=ax.transAxes, fontsize=9, color="#52514e")
ax.legend(loc="lower right", frameon=False, fontsize=9)
fig.tight_layout(); fig.savefig("efficient_frontier.png", facecolor=fig.get_facecolor())
